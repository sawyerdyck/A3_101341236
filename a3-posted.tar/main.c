#include <stdio.h>
#include "camera.h"
#include "photo.h"

int main(void) {
    // Create your arrays here. Remember to use correct sizes as defined in camera.h
    // And to handle error states in here, as main() handles the control flow.
    // Main shouldn't have any functions other than the main() function and any test / helper functions only needed inside main.

    return 0;
}