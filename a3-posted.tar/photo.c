#include <stdio.h>
#include "camera.h"
#include "photo.h"

/* Your code for the function implementations in photo.h should be place here.*/